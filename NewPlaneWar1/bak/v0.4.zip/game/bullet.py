"""子弹类的定义"""
import pygame
import constans


class Bullet(pygame.sprite.Sprite):
    """子弹类定义的实现"""

    # 子弹的存活状态
    active = True

    def __init__(self, screen, plane, speed=10):
        super().__init__()

        # 添加子弹的飞机、速度、屏幕、图片、音效、位置等属性
        self.plane = plane
        self.speed = speed
        self.screen = screen
        self.bullet_image = pygame.image.load(constans.BULLET_IMG)
        self.bullet_sound = pygame.mixer.Sound(constans.BULLET_SHOOT_SOUND)
        self.rect = self.bullet_image.get_rect()
        self.rect.top = self.plane.rect.top
        self.rect.centerx = self.plane.rect.centerx

        # 子弹产生时播放发射音效
        self.bullet_sound.set_volume(0.3)
        self.bullet_sound.play()

    def update(self, wars, *args):
        """子弹的更新方法"""

        # 子弹位置在不断移动
        self.rect.top -= self.speed

        # 子弹飞行的三种状态：存活、飞出屏幕、击中敌机
        if self.active and self.rect.top > 0:
            # 画出子弹
            self.screen.blit(self.bullet_image, self.rect)
            rest = pygame.sprite.spritecollide(self, wars.enemy_planes, False)
            if rest:
                for r in rest:
                    # 消除子弹
                    self.kill()
                    # 播放被击中的飞机动画
                    r.down_image()
                # 统计成绩

        elif self.rect.top < 0:
            # 飞出屏幕的子弹从精灵组里删除
            self.remove(self.plane.plane_bullet)
