"""游戏类整体的定义"""
import sys

import pygame

import constans
from game import plane


class War(object):
    """游戏类即战争定义的实现"""

    # 0.准备中，1.游戏中，2.结束时
    READY = 0
    PLAYING = 1
    OVER = 2

    # clock对象设置屏幕的刷新率，frame刷新率的参数
    frame = 0
    clock = pygame.time.Clock()

    def __init__(self):
        """游戏初始化"""
        pygame.init()

        # 获得屏幕对象Surface
        self.width, self.height = 480, 852
        self.screen = pygame.display.set_mode((self.width, self.height))

        # 游戏的状态
        self.status = self.READY

        # 背景图片1.游戏准备中，2.游戏结束的，图片
        self.bg = pygame.image.load(constans.BG_IMG)
        self.game_title = None
        self.game_title_rect = None
        self.start_btn = None
        self.start_btn_rect = None
        self.bg_over = None

        # 添加我方飞机
        self.our_plane = plane.OurPlane(self.screen)

        # 添加敌方飞机精灵组
        self.enemy_planes = pygame.sprite.Group()

        # 添加敌方飞机方法
        self.init_enemies(6)

    def ready_bg_img(self):
        """游戏准备状态的画面"""
        # 标题的载入
        self.game_title = pygame.image.load(constans.BG_IMG_TITLE)
        self.game_title_rect = self.game_title.get_rect()
        t_width, t_height = self.game_title.get_size()
        self.game_title_rect.topleft = ((self.width - t_width) // 2, int(self.height / 2 - t_height))

        # 开始按钮图片的载入
        self.start_btn = pygame.image.load(constans.BG_IMG_START_BTN)
        self.start_btn_rect = self.start_btn.get_rect()
        b_width, b_height = self.start_btn.get_size()
        self.start_btn_rect.topleft = ((self.width - b_width) // 2, self.height // 2 + b_height)

        # 准备画面的绘制
        self.screen.blit(self.bg, self.bg.get_rect())
        self.screen.blit(self.game_title, self.game_title_rect)
        self.screen.blit(self.start_btn, self.start_btn_rect)

    def play_img(self):
        """游戏进行时的画面"""

        self.screen.blit(self.bg, self.bg.get_rect())
        self.our_plane.update(self)
        self.our_plane.plane_bullet.update()
        self.enemy_planes.update()

    def over_bg_img(self):
        """游戏结束时的背景画面"""

        self.bg_over = pygame.image.load(constans.BG_OVER_IMG)

    def control_frame(self):
        """设置屏幕的刷新率"""
        self.clock.tick(60)
        self.frame += 1
        if self.frame >= 60:
            self.frame = 0

    def init_enemies(self, num):
        """添加num架小飞机此方法还可扩充，用分数控制大、中型飞机出场"""
        for i in range(num):
            sma_planes = plane.SmallPlane(self.screen)
            sma_planes.add(self.enemy_planes)

    def bind_event(self):
        """绑定事件方法，监听事件"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:

                """监听窗口关闭事件"""
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:

                """监听鼠标事件"""
                if self.status == self.READY:
                    self.status = self.PLAYING
                elif self.status == self.OVER:
                    self.status = self.READY

            elif event.type == pygame.KEYDOWN and self.status == self.PLAYING:

                """监听键盘事件"""
                if event.key == pygame.K_UP or event.key == pygame.K_w:
                    self.our_plane.move_up()
                elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                    self.our_plane.move_down()
                elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    self.our_plane.move_left()
                elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                    self.our_plane.move_right()
                elif event.key == pygame.K_SPACE:
                    self.our_plane.shoot_bullet()

    def game_run(self):
        """运行游戏"""
        while True:
            # 控制帧数率
            self.control_frame()

            # 监听事件
            self.bind_event()

            # 更新图片，进行绘制
            if self.status == self.READY:
                """开始界面绘制方法"""
                self.ready_bg_img()

            elif self.status == self.PLAYING:
                """游戏中画面绘制方法"""
                self.play_img()

            elif self.status == self.OVER:
                """游戏结束时画面绘制方法"""
                self.over_bg_img()

            # 屏幕更新
            pygame.display.flip()
