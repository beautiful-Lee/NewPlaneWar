"""飞机基类及其派生类的定义"""
import pygame

import constans
from game.bullet import Bullet


class Plane(pygame.sprite.Sprite):
    """飞机基类定义"""

    # 飞机的基本属性：图片、坠毁音效、爆炸图片、子弹、飞机存活状态等
    plane_images = []
    destroy_image = []
    down_sounds = None
    # 这里的子弹是一个精灵组对象，用来控制一系列的子弹用的！
    plane_bullet = pygame.sprite.Group()
    active = True

    def __init__(self, screen, speed=4):
        # 飞机属性的初始化
        super().__init__()
        self.screen = screen

        self.image_list = []
        self.destroy_image_list = []
        self.down_sounds = None
        self.speed = speed
        self.static_resource()

        self.image_rect = self.image_list[0].get_rect()

    # 静态资源加载
    def static_resource(self):
        for img in self.plane_images:
            self.image_list.append(pygame.image.load(img))

        for img in self.destroy_image:
            self.destroy_image_list.append(pygame.image.load(img))

        if self.down_sounds:
            self.down_sounds = self.down_sounds

    # 存活状态下所能做的事情：移动位置、发射子弹、飞机的动画绘制
    def move_up(self):
        self.image_rect.top -= self.speed

    def move_down(self):
        self.image_rect.top += self.speed

    def move_left(self):
        self.image_rect.left -= self.speed

    def move_right(self):
        self.image_rect.left += self.speed

    def shoot_bullet(self):
        pass

    # 死亡状态下能做的事情：爆炸动画绘制、
    def down_image(self):
        pass


class OurPlane(Plane):
    """我方飞机类定义"""
    plane_images = [constans.OUR_PLANE_IMG_1, constans.OUR_PLANE_IMG_2]
    destroy_image = constans.OUR_DESTROY_IMG_LIST
    down_sounds = constans.OUR_DESTROY_SOUND

    def __init__(self, screen, speed=10):
        """在重写的__init__方法中只对飞机首次出现的位置进行了修改"""
        super().__init__(screen, speed)
        self.s_width, self.s_height = self.screen.get_size()
        self.o_width, self.o_height = self.image_list[0].get_size()
        self.image_rect.top = int(self.s_height - self.o_height)
        self.image_rect.left = int((self.s_width - self.o_width) / 2)

    def update(self, war):
        """飞机的飞行状态方法：包含飞机动画的切换，碰撞检测"""
        # 飞机的飞行动画，每隔5帧切换
        if war.frame % 5:
            self.screen.blit(self.image_list[0], self.image_rect)
        else:
            self.screen.blit(self.image_list[1], self.image_rect)

    # 飞机的控制方法：上下左右，以及超出屏幕的限制条件
    def move_up(self):
        super().move_up()
        if self.image_rect.top <= 0:
            self.image_rect.top = 0

    def move_down(self):
        super().move_down()
        if self.image_rect.top >= self.s_height - self.o_height:
            self.image_rect.top = self.s_height - self.o_height

    def move_left(self):
        super().move_left()
        if self.image_rect.left <= 0:
            self.image_rect.left = 0

    def move_right(self):
        super().move_right()
        if self.image_rect.left >= self.s_width - self.o_width:
            self.image_rect.left = self.s_width - self.o_width

    # 飞机发射子弹的方法
    def shoot_bullet(self):
        """调用发射子弹方法时创建一个子弹对象，并将其添加到精灵组中"""
        bullet = Bullet(self.screen, self)
        self.plane_bullet.add(bullet)


class SmallPlane(Plane):
    """敌方小型飞机类定义"""
    pass


class MediumPlane(Plane):
    """敌方中型飞机类定义"""
    pass


class LargePlane(Plane):
    """敌方大型飞机类定义"""
    pass
